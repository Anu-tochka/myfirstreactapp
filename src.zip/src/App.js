import Message from './Message.js';
import './App.css';

function App() {
	let mes = "Hello!";
  return (
   
   <Message message={mes} />
 
  );
}

export default App;
